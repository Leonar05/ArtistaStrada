import java.util.Random;
import java.util.concurrent.Semaphore;

public class StreetArtist {
	private static final int posti = 4; // Numero di sedie disponibili
	private static final int attesa = 5000; // Tempo massimo di attesa per un ritratto (in millisecondi)

	static Semaphore seatsSemaphore; // Semaforo per gestire l'accesso alle sedie

	public StreetArtist() {
		setSeatsSemaphore(new Semaphore(posti, true));
	}

	public void startSimulation() {
		Thread artistThread = new Thread(new Artist());
		artistThread.start();

		Random random = new Random();
		int clientNumber = 1;

		while (true) {
			try {
				Thread.sleep(random.nextInt(2000)); // Tempo casuale di arrivo di un cliente (da 0 a 2 secondi)
				Thread clientThread = new Thread(new Client(clientNumber));
				clientThread.start();
				clientNumber++;
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public static Semaphore getSeatsSemaphore() {
		return seatsSemaphore;
	}

	public static void setSeatsSemaphore(Semaphore seatsSemaphore) {
		StreetArtist.seatsSemaphore = seatsSemaphore;
	}
	/*

	public static Semaphore getSeatsSemaphore() {
		// TODO Auto-generated method stub
		return null;
	}
	*/

	public static int getAttesa() {
		return attesa;
	}
	
}