import java.util.Random;

class Artist implements Runnable {
        @Override
        public void run() {
            while (true) {
                try {
                    try {
						StreetArtist.getSeatsSemaphore().acquire();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} // Occupa una sedia
                    System.out.println("L'artista sta facendo il ritratto...");
                    
                    // Simulazione del tempo impiegato per fare un ritratto
                    Thread.sleep(new Random().nextInt(5000));
                    
                    System.out.println("Il ritratto è pronto. Si è liberata una sedia.");
                    StreetArtist.seatsSemaphore.release(); // Rilascia la sedia
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }