import java.util.Random;

class Client implements Runnable {
        private int clientNumber;
        
        public Client(int clientNumber) {
            this.clientNumber = clientNumber;
        }
        
        @Override
        public void run() {
            try {
                if (StreetArtist.getSeatsSemaphore().getQueueLength()==0
                		//StreetArtist.getSeatsSemaphore().getQueueLength()==0
                		//StreetArtist.seatsSemaphore.tryAcquire(StreetArtist.getMaxWaitTime())
                		) {
                    System.out.println("Il cliente " + clientNumber + " si è seduto.");
                    Thread.sleep(new Random().nextInt(3000)); // Tempo casuale di attesa per il ritratto (da 0 a 3 secondi)
                    System.out.println("Il cliente " + clientNumber + " ha ottenuto il suo ritratto va via.");
                    StreetArtist.seatsSemaphore.release(); // Rilascia la sedia
                } else {
                    System.out.println("Il cliente " + clientNumber + " ha rinunciato a farsi fare il ritratto.");
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }