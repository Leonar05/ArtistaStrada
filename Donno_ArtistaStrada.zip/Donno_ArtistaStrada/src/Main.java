public class Main {

	public static void main(String[] args) {
        StreetArtist streetArtist = new StreetArtist();
        streetArtist.startSimulation();
    }

	}
